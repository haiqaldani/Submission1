package com.example.submission1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class FilmAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<Film> film = new ArrayList<>();

    //constructor hasil generate context
    FilmAdapter(Context context) {
        this.context = context;
    }
    //setter hasil generate film
    void setFilm(ArrayList<Film> film) {
        this.film = film;
    }


    @Override
    public int getCount() {
        return film.size();
    }

    @Override
    public Object getItem(int i) {
        return film.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View itemView = view;
        if (itemView == null) {
            itemView = LayoutInflater.from(context).inflate(R.layout.list_film, viewGroup, false);
        }



        ViewHolder viewHolder = new ViewHolder(itemView);
        Film film = (Film) getItem(i);
        viewHolder.bind(film);
        return itemView;
    }

    private class ViewHolder {
        private TextView JudulFilm;
        private TextView TahunFilm;
        private TextView GenreFilm;
        private ImageView GambarFilm;

        ViewHolder(View view){
            JudulFilm = view.findViewById(R.id.judul_film);
            TahunFilm = view.findViewById(R.id.tahun_film);
            GenreFilm = view.findViewById(R.id.genre_film);
            GambarFilm = view.findViewById(R.id.gbr_film);
        }

        void bind(Film film){
            JudulFilm.setText(film.getJudul());
            TahunFilm.setText(film.getTahun());
            GenreFilm.setText(film.getGenre());
            GambarFilm.setImageResource(film.getGbr());
        }
    }

}
