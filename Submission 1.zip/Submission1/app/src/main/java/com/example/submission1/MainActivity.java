package com.example.submission1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private FilmAdapter adapter;
    private ArrayList<Film> arrnyafilm;

    private String[] judulfilmm;
    private String[] tahunfilmm;
    private String[] genrefilmm;
    private String[] detailfilmm;
    private TypedArray gbrfilmm;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ListView list_film = findViewById(R.id.listview);
        adapter = new FilmAdapter(this);
        list_film.setAdapter(adapter);

        prepare();
        addItem();

        list_film.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Film film = new Film();
                Intent intent = new Intent(MainActivity.this,DetailFilm.class);
                film.setJudul(arrnyafilm.get(i).getJudul());
                film.setTahun(arrnyafilm.get(i).getTahun());
                film.setGbr(arrnyafilm.get(i).getGbr());
                film.setDetail(arrnyafilm.get(i).getDetail());
                film.setGenre(arrnyafilm.get(i).getGenre());
                intent.putExtra(DetailFilm.EXTRA_FILM, film);
                startActivity(intent);
            }
        });
    }


    private void addItem() {
        arrnyafilm = new ArrayList<>();
        for (int i = 0; i < judulfilmm.length; i++) {
            Film f = new Film();
            f.setGbr(gbrfilmm.getResourceId(i, -1));
            f.setJudul(judulfilmm[i]);
            f.setTahun(tahunfilmm[i]);
            f.setGenre("Genre Film : " +genrefilmm[i]);
            f.setDetail("Sinopsis Film :\n"+detailfilmm[i]);
//            f.setPemain(pemainfilmm.getString());
            arrnyafilm.add(f);
        }
        adapter.setFilm(arrnyafilm);
    }

    private void prepare() {
        judulfilmm = getResources().getStringArray(R.array.arrayjudul_film);
        tahunfilmm = getResources().getStringArray(R.array.arraytahun_film);
        genrefilmm = getResources().getStringArray(R.array.arraygenre_film);
        detailfilmm = getResources().getStringArray(R.array.arraydetail_film);
        gbrfilmm = getResources().obtainTypedArray(R.array.arraygbr_film);
    }

}